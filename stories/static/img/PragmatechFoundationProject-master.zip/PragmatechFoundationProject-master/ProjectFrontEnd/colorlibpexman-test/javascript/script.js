// let menu = document.querySelector("ul")
// for(let i=0;i<10;i++){
//     if(i==0)[
//         console.log("ne tekdi ne cutdu")
//     ]
//     else if(i%2==1){
//         console.log(i)
//     }
//     else {
//         console.log("bu eded sehfdir deye gostermeyecey")
//     }
// }